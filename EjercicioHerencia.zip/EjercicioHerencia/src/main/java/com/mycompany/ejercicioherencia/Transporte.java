/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicioherencia;

/**
 *
 * @author pc
 */
public class Transporte {
    
    private double velocidad;
    private String nombre;

    
    public void mostrar(){
        System.out.println("Soy un medio de Transporte");
    }
    
    public void setVelocidad(double v){
        
        velocidad= v;
    }
    
    public double getVelocidad(){
        
        return velocidad;
    }
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String n) {
        nombre = n;
    }
    
}
