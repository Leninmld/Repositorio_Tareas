/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicioherencia;

/**
 *
 * @author pc
 */
public class Coche extends Transporte{
    
    private String modelo;

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String m) {
        modelo = m;
    }
    
    
    
}
