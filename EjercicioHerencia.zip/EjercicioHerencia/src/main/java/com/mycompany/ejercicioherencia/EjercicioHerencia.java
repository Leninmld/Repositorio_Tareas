/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicioherencia;

 
public class EjercicioHerencia {

    public static void main(String[] args) {
        
        Coche c1 = new Coche ();
        c1.setModelo("MK344");
        c1.setVelocidad(2344);

        System.out.println("Modelo :"+ c1.getModelo());
        
        
    }
}
