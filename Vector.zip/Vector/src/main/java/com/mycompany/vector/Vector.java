/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.vector;

import java.util.Scanner;

/**
 *
 * @author pc
 */

public class Vector {

    public static void main(String[] args) {
        
        int vector [] = new int [15];
        Scanner sc = new Scanner (System.in);
        
        for (int i = 0; i<15; i++){
            
            System.out.println("Ingrese un numero para el vector:" );
            vector [i] = sc.nextInt();
        }
         int cont = 0;
         for (int i = 0; i<15; i++){
            
          if (vector [i] == 3){
              cont = cont+1;
              
          }
        }
        
         System.out.println("La  cantidad de numeros 3 que hay en el vector es: " + cont);
    }
}
